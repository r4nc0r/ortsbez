java -cp '.:geo.jar' pp.dorenda.client2.testapp.TestActivity  -m 'webservice;geosrv.informatik.fh-nuernberg.de'  -c pp.dorenda.client2.additional.UniversalPainter -a result.txt
